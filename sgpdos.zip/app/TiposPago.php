<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TiposPago extends Model
{
    protected $fillable = [
    	'decripcion'
    ];
}
