<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\EstadosFinanciero;
use Faker\Generator as Faker;

$factory->define(EstadosFinanciero::class, function (Faker $faker) {
    return [
        //
    ];
});
