<script>
//paste this code under the head tag or in a separate js file.
// Wait for window load
$(window).on('load', function() {
    // Animate loader off screen
    $('.se-pre-con').fadeOut(1000);
});
</script>
{{-- Preloader --}}
<div class="se-pre-con"></div>