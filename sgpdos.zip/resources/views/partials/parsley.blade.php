<script src="{{ asset('js/parsley.min.js') }}"></script>
<script src="{{ asset('js/parsleyes.js') }}"></script>