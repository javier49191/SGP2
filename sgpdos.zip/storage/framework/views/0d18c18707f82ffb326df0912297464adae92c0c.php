<?php $__env->startSection('content'); ?>
<div class="container">


	<div class="card">
		<h5 class="card-header">Registrar Alumno</h5>
		<div class="card-body">
			<form action="<?php echo e(route('alumnos.store')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-6 form-group">
						<label for="nombre">Nombre</label>
						<input type="text" class="form-control <?php echo e($errors->has('nombre') ? 'is-invalid' : ''); ?>" name="nombre" value="<?php echo e(old('nombre')); ?>">

						<?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-6 form-group">
						<label for="alias">Alias</label>
						<input type="text" class="form-control <?php echo e($errors->has('alias') ? 'is-invalid' : ''); ?>" name="alias" value="<?php echo e(old('alias')); ?>">
						<?php if ($errors->has('alias')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alias'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<div class="row">
					<div class="col-md-6 form-group">
						<label for="apellido">Apellido</label>
						<input type="text" class="form-control <?php echo e($errors->has('apellido') ? 'is-invalid' : ''); ?>" name="apellido" value="<?php echo e(old('apellido')); ?>">
						<?php if ($errors->has('apellido')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('apellido'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-6 form-group">
						<label for="dni">DNI</label>
						<input type="text" class="form-control <?php echo e($errors->has('dni') ? 'is-invalid' : ''); ?>" name="dni" value="<?php echo e(old('dni')); ?>">
						<?php if ($errors->has('dni')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dni'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<div class="row">
					<div class="col-md-6 form-group">
						<label for="grado">Grado</label>
						<input type="text" class="form-control <?php echo e($errors->has('grado') ? 'is-invalid' : ''); ?>" name="grado" value="<?php echo e(old('grado')); ?>">
						<?php if ($errors->has('grado')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('grado'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-6 form-group">
						<label for="fecha_nacimiento">Fecha de nacimiento</label>
						<input type="date" class="form-control <?php echo e($errors->has('fecha_nacimiento') ? 'is-invalid' : ''); ?>" name="fecha_nacimiento" value="<?php echo e(old('fecha_nacimiento')); ?>">
						<?php if ($errors->has('fecha_nacimiento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fecha_nacimiento'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>

				</div>

				<div class="row">
					<div class="form-check ml-3">
						<input class="form-check-input" type="checkbox" value="1" name="es_alumno[0]">
						
						<label class="form-check-label" for="es_alumno">
							Es alumno
						</label>
					</div>
				</div>

				<div class="row mt-3">
					<div class="col-md-12 form-group">
						<label for="observaciones">Observaciones</label>
						<textarea name="observaciones" class="form-control <?php echo e($errors->has('observaciones') ? 'is-invalid' : ''); ?>"><?php echo e(old('observaciones')); ?></textarea>
						<?php if ($errors->has('observaciones')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('observaciones'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e(ucfirst($message)); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<button type="submit" class="btn btn-primary">Guardar</button>

			</form>
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp\resources\views/alumnos/create.blade.php ENDPATH**/ ?>