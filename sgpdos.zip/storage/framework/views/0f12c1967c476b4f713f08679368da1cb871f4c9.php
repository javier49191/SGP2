<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<b>Detalles de alumno: <?php echo e($alumno->nombre); ?></b>
				</div>

				<div class="card-body">
					<div class="row">
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Nombre: </b><?php echo e($alumno->nombre); ?></p>
							<p class="form-control"><b>Alias: </b><?php echo e($alumno->alias); ?></p>

						</div>
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Apellido: </b><?php echo e($alumno->apellido); ?></p>
							<p class="form-control"><b>DNI: </b><?php echo e($alumno->dni); ?></p>

						</div>
					</div>
					<div class="row">
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Fecha de nacimiento: </b><?php echo e($alumno->fecha_nacimiento->format('d-m-Y')); ?>

								<span class="badge badge-light">
								(<?php echo e(Carbon\Carbon::parse($alumno->fecha_nacimiento)->age); ?> años)
								</span>
							</p>
						</div>
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Grado: </b><?php echo e($alumno->grado); ?></p>
						</div>

					</div>
					<hr>
					<div class="row">
						<div class="col-md-12 form-group">
							<p class=""><h6>Observaciones:</h6><br><?php echo $alumno->observaciones; ?>

							</p>
						</div>
					</div>
					<hr>
					<a href="<?php echo e(route('alumnos.edit', $alumno->id)); ?>" class="btn btn-primary">Editar</a>
				</div>

				
				<div class="card-header text-center">
					<b class="">Padrinos vinculados</b>
				</div>
				<div class="table-responsive col-md-12">
					<table class="table table-hover">
						<thead>
							<tr>
								<th scope="col" class="text-center">Nombre</th>
								<th scope="col" class="text-center">Apellido</th>
								<th scope="col" class="text-center">Fecha de vinculación</th>
								<th scope="col" class="text-center">Acciones</th>
							</tr>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $vinculaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vinculacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td class="text-center">
									<a href="<?php echo e(route('padrinos.show', $vinculacion->padrino->id)); ?>">
										<?php echo e($vinculacion->padrino->nombre); ?>

									</a>
								</td>
								<td class="text-center"><?php echo e($vinculacion->padrino->apellido); ?></td>
								<td class="text-center"><?php echo e($vinculacion->created_at->format('d-m-Y')); ?></td>
								<td class="text-center">
									<form action="<?php echo e(route('vinculaciones.destroy', $vinculacion->id)); ?>" method="POST">
										<?php echo csrf_field(); ?>
										<?php echo method_field('DELETE'); ?>
										<button class="btn-delete btn btn-sm btn-danger" type="button">
											<i class="icon-cancel_circle icon1x"></i>
										</button>
									</form>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

							<?php endif; ?>
						</tbody>
					</table>
				</div>
				
			</div>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('partials.SweetAlert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/alumnos/show.blade.php ENDPATH**/ ?>