<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-4">
			<img src="<?php echo e(asset('images/403.png')); ?>" class="img-fluid" alt="">
		</div>
		<div class="col-md-6 mt-5">
			<h2 class="text-center">Acceso no autorizado</h2>
			<h4>Por razones de seguridad, el usuario con rol <i class="text-primary"><?php echo e(Auth::user()->role->nombre); ?></i> no tiene permisos para ver la página solicitda.</h4>
			<h4>Por favor, contacte al administrador del sistema.</h4>
			<h4>Gracias!</h4>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/errors/403.blade.php ENDPATH**/ ?>