<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="card">
		<h5 class="card-header">Registrar Aporte</h5>
		<div class="card-body">

			<form action="<?php echo e(route('aportes.store')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-12">
						<label for="padrino_id">Buscar Padrinos</label>
						<select class="custom-select <?php echo e($errors->has('padrino_id') ? 'is-invalid' : ''); ?>" name="padrino_id">
							<option selected disabled>Seleccionar...</option>
							<?php $__empty_1 = true; $__currentLoopData = $padrinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $padrino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<option value="<?php echo e($padrino->id); ?>"><?php echo e($padrino->nombre); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<option>No existen registros</option>
							<?php endif; ?>
						</select>
						<?php if ($errors->has('padrino_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('padrino_id'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<div class="row mt-3">
					<div class="col-md-4">
						<label for="tipo_pago_id">Medio de pago</label>
						<select class="custom-select <?php echo e($errors->has('tipo_pago_id') ? 'is-invalid' : ''); ?>" name="tipo_pago_id">
							<option selected value>Seleccionar...</option>
							<?php $__empty_1 = true; $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->descripcion); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<option>No existen registros</option>
							<?php endif; ?>
						</select>
						<?php if ($errors->has('tipo_pago_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tipo_pago_id'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-4">
						<label for="monto_pago">Monto</label>
						<input type="text" class="form-control <?php echo e($errors->has('monto_pago') ? 'is-invalid' : ''); ?>" name="monto_pago" value="<?php echo e(old('monto_pago')); ?>">

						<?php if ($errors->has('monto_pago')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('monto_pago'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-4">
						<label for="fecha_pago">Fecha del pago</label>
						<input type="date" class="form-control <?php echo e($errors->has('fecha_pago') ? 'is-invalid' : ''); ?>" name="fecha_pago" value="<?php echo e(old('fecha_pago')); ?>">

						<?php if ($errors->has('fecha_pago')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fecha_pago'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<div class="row mt-3">
					<div class="col-md-4">
						<label for="factura">Factura</label>
						<input type="text" class="form-control <?php echo e($errors->has('factura') ? 'is-invalid' : ''); ?>" name="factura" value="<?php echo e(old('factura')); ?>">

						<?php if ($errors->has('factura')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('factura'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-4">
						<label for="comprobante">Comprobante</label>
						<input type="text" class="form-control <?php echo e($errors->has('comprobante') ? 'is-invalid' : ''); ?>" name="comprobante" value="<?php echo e(old('comprobante')); ?>">

						<?php if ($errors->has('comprobante')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comprobante'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-4">
						<label for="descripcion">Descripción</label>
						<input type="text" class="form-control <?php echo e($errors->has('descripcion') ? 'is-invalid' : ''); ?>" name="descripcion" value="<?php echo e(old('descripcion')); ?>">

						<?php if ($errors->has('descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descripcion'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>


				<button type="submit" class="btn btn-primary mt-3">Guardar</button>

			</form>
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp\resources\views/aportes/create.blade.php ENDPATH**/ ?>