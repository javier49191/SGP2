<?php $__env->startSection('links'); ?>
<?php echo $__env->make('partials.DateCKEditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/parsley.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="card">
		<h5 class="card-header">Editar alumno: <?php echo e($alumno->nombre); ?></h5>
		<div class="card-body">
			<form action="<?php echo e(route('alumnos.update', $alumno->id)); ?>" method="POST" data-parsley-validate="">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<div class="row">
					<div class="col-md-6 form-group">
						<label for="nombre">Nombre</label>
						<input type="text" class="form-control <?php echo e($errors->has('nombre') ? 'is-invalid' : ''); ?>" name="nombre" value="<?php echo e(old('nombre', $alumno->nombre)); ?>" data-parsley-required>

						<?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-6 form-group">
						<label for="alias">Alias</label>
						<input type="text" class="form-control <?php echo e($errors->has('alias') ? 'is-invalid' : ''); ?>" name="alias" value="<?php echo e(old('alias', $alumno->alias)); ?>">
						<?php if ($errors->has('alias')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alias'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<div class="row">
					<div class="col-md-6 form-group">
						<label for="apellido">Apellido</label>
						<input type="text" class="form-control <?php echo e($errors->has('apellido') ? 'is-invalid' : ''); ?>" name="apellido" value="<?php echo e(old('apellido', $alumno->apellido)); ?>" data-parsley-required>
						<?php if ($errors->has('apellido')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('apellido'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-6 form-group">
						<label for="dni">DNI</label>
						<input type="text" class="form-control <?php echo e($errors->has('dni') ? 'is-invalid' : ''); ?>" name="dni" value="<?php echo e(old('dni', $alumno->dni)); ?>" data-parsley-required data-parsley-type="number" data-parsley-min="30000000">
						<?php if ($errors->has('dni')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dni'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<div class="row">
					<div class="col-md-6 form-group">
						<label for="grado">Grado</label>
						<select name="grado" id="grado" class="custom-select <?php echo e($errors->has('grado') ? 'is-invalid' : ''); ?>" required>
							<option selected disabled>Seleccionar...</option>
							<option value="1" <?php echo e(($alumno->grado == 1) ? 'selected' : ''); ?>>1</option>
							<option value="2" <?php echo e(($alumno->grado == 2) ? 'selected' : ''); ?>>2</option>
							<option value="3" <?php echo e(($alumno->grado == 3) ? 'selected' : ''); ?>>3</option>
							<option value="4" <?php echo e(($alumno->grado == 4) ? 'selected' : ''); ?>>4</option>
							<option value="5" <?php echo e(($alumno->grado == 5) ? 'selected' : ''); ?>>5</option>
							<option value="6" <?php echo e(($alumno->grado == 6) ? 'selected' : ''); ?>>6</option>
						</select>
						<?php if ($errors->has('grado')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('grado'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-6 form-group">
						<label for="fecha_nacimiento">Fecha de nacimiento</label>
						<input type="text" class="form-control <?php echo e($errors->has('fecha_nacimiento') ? 'is-invalid' : ''); ?>" name="fecha_nacimiento" id='datetimepicker1' value="<?php echo e(old('fecha_nacimiento', $alumno->fecha_nacimiento->format('d-m-Y'))); ?>">

						<?php if ($errors->has('fecha_nacimiento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fecha_nacimiento'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>

				</div>

				<div class="row">
					<div class="form-check">
						<input type="checkbox" class="switch_1 radio-inline" value="1" name="es_alumno[0]" <?php echo e(($alumno->es_alumno == 1) ? 'checked' : ''); ?> id="es_alumno">
						<label for="es_alumno" class="label-check">
							Es alumno
						</label>
					</div>
				</div>

				<div class="row mt-3">
					<div class="col-md-12 form-group">
						<label for="observaciones">Observaciones</label>
						<textarea id="observaciones" name="observaciones" class="form-control <?php echo e($errors->has('observaciones') ? 'is-invalid' : ''); ?>"><?php echo e(old('observaciones', $alumno->observaciones)); ?></textarea>
						<?php if ($errors->has('observaciones')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('observaciones'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e(ucfirst($message)); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<button type="submit" class="btn btn-primary">Guardar</button>

			</form>
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(function () {
		$('#datetimepicker1').datetimepicker({
			locale: 'es',
			viewMode: 'days',
        	format: 'DD-MM-YYYY'
		});
	});
</script>
<script>
	CKEDITOR.replace( 'observaciones' );
</script>

<script src="<?php echo e(asset('js/parsley.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/parsleyes.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/alumnos/edit.blade.php ENDPATH**/ ?>