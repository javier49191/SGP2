<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/parsley.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<form action="<?php echo e(route('vinculaciones.store')); ?>" method="POST" data-parsley-validate="">
				<?php echo csrf_field(); ?>
				<div class="card">
					<div class="card-header bg-secondary text-white">
						<h6>Crear Vinculación</h6>
					</div>
					<div class="card-body">
						<div class="form-group">
							<div class="card-header bg-primary text-white rounded">
								<label for="padrino">
									<b>Seleccione un padrino</b>
								</label>								
							</div>
							<div class="card-body">							

								<select class="form-control <?php echo e($errors->has('padrino_id') ? 'is-invalid' : ''); ?>" id="padrino_id" name="padrino_id" data-parsley-required>
									<option value="" disabled selected>Select...</option>
									<?php $__empty_1 = true; $__currentLoopData = $padrinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $padrino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<option value="<?php echo e($padrino->id); ?>" <?php echo e(old('padrino_id')); ?>

										data-apellido="<?php echo e($padrino->apellido); ?>"
										data-alias="<?php echo e($padrino->alias); ?>"
										data-dni="<?php echo e($padrino->dni); ?>"
										data-cuil="<?php echo e($padrino->cuil); ?>"
										data-email="<?php echo e($padrino->email); ?>"
										data-segundo_email="<?php echo e($padrino->segundo_email); ?>"
										data-telefono="<?php echo e($padrino->telefono); ?>"
										data-segundo_telefono="<?php echo e($padrino->segundo_telefono); ?>"
										><?php echo e($padrino->nombre); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
										<?php endif; ?>					
									</select>
									<?php if ($errors->has('padrino_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('padrino_id'); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<b>Infomación del padrino seleccionado</b>
							<div class="row mt-2">
								<div class="col-md-3">
									<div class="from-group">
										<label for="apellido">Apellido</label>
										<input type="text" disabled id="apellido" class="form-control">
									</div>
								</div>
								<div class="col-md-3">
									<label for="alias">Alias</label>
									<input type="text" disabled id="alias" class="form-control">
								</div>
								<div class="col-md-3">
									<label for="dni">DNI</label>
									<input type="text" disabled id="dni" class="form-control">
								</div>
								<div class="col-md-3">
									<label for="cuil">CUIL</label>
									<input type="text" disabled id="cuil" class="form-control">
								</div>
							</div>
							
							<div class="row">
								<div class="col-md-3">
									<div class="from-group">
										<label for="email">Email</label>
										<input type="text" disabled id="email" class="form-control">
									</div>
								</div>
								<div class="col-md-3">
									<label for="segundo_email">Segundo Email</label>
									<input type="text" disabled id="segundo_email" class="form-control">
								</div>
								<div class="col-md-3">
									<label for="telefono">Teléfono</label>
									<input type="text" disabled id="telefono" class="form-control">
								</div>
								<div class="col-md-3">
									<label for="segundo_telefono">Segundo teléfono</label>
									<input type="text" disabled id="segundo_telefono" class="form-control">
								</div>
							</div>
							
							<hr class="bg-dark">
							<div class="form-group">
								<div class="card-header bg-primary text-white rounded">
									<label for="alumno">
										<b>Seleccione un alumno</b>
									</label>									
								</div>
								<div class="card-body">
									
								
								<select class="form-control <?php echo e($errors->has('alumno_id') ? 'is-invalid' : ''); ?>" id="alumno_id" name="alumno_id" data-parsley-required>
									<option value="" disabled selected>Select...</option>
									<?php $__empty_1 = true; $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<option value="<?php echo e($alumno->id); ?>" 
										data-apellido="<?php echo e($alumno->apellido); ?>"
										data-alias="<?php echo e($alumno->alias); ?>"
										data-dni="<?php echo e($alumno->dni); ?>"
										data-grado="<?php echo e($alumno->grado); ?>"
										><?php echo e($alumno->nombre); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
										<?php endif; ?>					
									</select>
									<?php if ($errors->has('alumno_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alumno_id'); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
								</div>
								<b>Infomación del alumno seleccionado</b>
								<div class="row mt-2">
									<div class="col-md-3">
										<div class="from-group">
											<label for="apellidoAlumno">Apellido</label>
											<input type="text" disabled id="apellidoAlumno" class="form-control">
										</div>
									</div>
									<div class="col-md-3">
										<label for="aliasAlumno">Alias</label>
										<input type="text" disabled id="aliasAlumno" class="form-control">
									</div>
									<div class="col-md-3">
										<label for="dniAlumno">DNI</label>
										<input type="text" disabled id="dniAlumno" class="form-control">
									</div>
									<div class="col-md-3">
										<label for="cuilAlumno">Grado</label>
										<input type="text" disabled id="gradoAlumno" class="form-control">
									</div>
								</div>
								<hr class="bg-dark">
								<div class="row mt-3">
									<div class="form-check">
										<input type="checkbox" class="switch_1 radio-inline" value="1" name="se_conocen[0]" id="se_conocen">
										<label for="se_conocen" class="label-check">
											Se cononen
										</label>
									</div>
								</div>
								
								<div class="row mt-3">
									<div class="col-md-12">
										<button type="submit" class="btn btn-primary">
											Guardar
										</button>									
									</div>
								</div>
							</div>
							
						</div>
					</form>			
				</div>
			</div>
		</div>
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('scripts'); ?>
		<script src="<?php echo e(asset('js/parsley.min.js')); ?>"></script>
		<script src="<?php echo e(asset('js/parsleyes.js')); ?>"></script>
		<script>
			$('select[name="padrino_id"]').on('change',function(e){
				$('#apellido').val($(this).children('option:selected').data('apellido'));
				$('#alias').val($(this).children('option:selected').data('alias'));
				$('#dni').val($(this).children('option:selected').data('dni'));
				$('#cuil').val($(this).children('option:selected').data('cuil'));
				$('#email').val($(this).children('option:selected').data('email'));
				$('#segundo_email').val($(this).children('option:selected').data('segundo_email'));
				$('#telefono').val($(this).children('option:selected').data('telefono'));
				$('#segundo_telefono').val($(this).children('option:selected').data('segundo_telefono'));
			});
		</script>
		<script>
			$('select[name="alumno_id"]').on('change',function(e){
				$('#apellidoAlumno').val($(this).children('option:selected').data('apellido'));
				$('#aliasAlumno').val($(this).children('option:selected').data('alias'));
				$('#dniAlumno').val($(this).children('option:selected').data('dni'));
				$('#gradoAlumno').val($(this).children('option:selected').data('grado'));
			});
		</script>
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/vinculaciones/create.blade.php ENDPATH**/ ?>