<?php $__env->startSection('links'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<b>Detalles de usuario: <?php echo e($user->name); ?></b>
				</div>

				<div class="card-body">
					<div class="row">
						<div class="col-md-6 form-group">
							<img class="imagenShow" src="<?php echo e(asset('images/avatar/')); ?>/<?php echo e($user->avatar); ?>" title="avatar de <?php echo e($user->name); ?>">
						</div>
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Nombre: </b><?php echo e($user->name); ?></p>
							<p class="form-control"><b>Email: </b><?php echo e($user->email); ?></p>
							<p class="form-control"><b>Apellido: </b><?php echo e($user->last_name); ?></p>
							<p class="form-control"><b>Registrado: </b><?php echo e($user->created_at->format('d-m-Y')); ?></p>
							<p class="form-control"><b>Rol: </b><?php echo e($user->role->nombre); ?></p>
							<p class="form-control"><b>Descripción: </b><?php echo e($user->role->descripcion); ?></p>

						</div>
						
					</div>
					
				</div>
			</div>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/users/show.blade.php ENDPATH**/ ?>