<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<b>Detalles de padrino: <?php echo e($padrino->nombre); ?></b>
				</div>

				<div class="card-body">
					<div class="row">
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Nombre: </b><?php echo e($padrino->nombre); ?></p>
							<p class="form-control"><b>Alias: </b><?php echo e($padrino->alias); ?></p>

						</div>
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Apellido: </b><?php echo e($padrino->apellido); ?></p>
							<p class="form-control"><b>Contacto: </b><?php echo e($padrino->contacto); ?></p>

						</div>
					</div>
					<div class="row">
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Email: </b><?php echo e($padrino->email); ?></p>
							<p class="form-control"><b>Teléfono: </b><?php echo e($padrino->telefono); ?></p>
						</div>
						<div class="col-md-6 form-group">
							<p class="form-control"><b>Segundo email: </b><?php echo e($padrino->segundo_email); ?></p>
							<p class="form-control"><b>Segundo teléfono: </b><?php echo e($padrino->segundo_telefono); ?></p>
						</div>
					</div>
				</div>

					
					<div class="card-header text-center">
						<b class="">Alumnos vinculados</b>
					</div>
					<div class="table-responsive col-md-12">
						<table class="table table-hover">
							<thead>
								<tr>
									<th scope="col" class="text-center">Nombre</th>
									<th scope="col" class="text-center">Apellido</th>
									<th scope="col" class="text-center">Grado</th>
									<th scope="col" class="text-center">Fecha de vinculación</th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $vinculaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vinculacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td class="text-center"><?php echo e($vinculacion->alumno->nombre); ?></td>
									<td class="text-center"><?php echo e($vinculacion->alumno->apellido); ?></td>
									<td class="text-center"><?php echo e($vinculacion->alumno->grado); ?></td>
									<td class="text-center"><?php echo e($vinculacion->created_at->format('d-m-Y')); ?></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

								<?php endif; ?>
							</tbody>
						</table>
					</div>
					
			</div>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
	<?php if(Session::has('info')): ?>
	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-top-right",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "100",
		"hideDuration": "1000",
		"timeOut": "3000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "slideUp"
	}
	toastr.success("<?php echo e(Session::get('info')); ?>");

	<?php endif; ?>
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp\resources\views/padrinos/show.blade.php ENDPATH**/ ?>