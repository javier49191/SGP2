<?php $__env->startSection('loader'); ?>
<?php echo $__env->make('partials.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<b>Usuarios</b>
					<a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-success float-right">
						Registrar usuario
					</a>
				</div>

				<div class="card-body table-responsive">
					<table id="users" class="table table-bordered table-hover" style="width:100%">
						<thead>
							<th>Avatar</th>
							<th>Nombre</th>
							<th>Apellido</th>
							<th>Email</th>

							<th class="text-center">Rol</th>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td width="5%">
									<img src="<?php echo e(asset('images/avatar/')); ?>/<?php echo e($user->avatar); ?>" title="avatar de <?php echo e($user->name); ?>" alt="" class="thumbnail">
								</td>
								<td style="vertical-align: middle;">
									<a href="<?php echo e(route('usuarios.show', $user->id)); ?>"><?php echo e($user->name); ?></a>
									<span class="muted"><?php echo e((Auth::user()->id == $user->id) ? ' - (Actual)':''); ?></span>
								</td>
								<td style="vertical-align: middle;"><?php echo e($user->last_name); ?></td>
								<td style="vertical-align: middle;"><?php echo e($user->email); ?></td>

								<td class="text-center" style="vertical-align: middle;">
									<span class="badge badge-pill badge-success">
										<?php echo e($user->role->nombre); ?>

									</span>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td class="alert alert-danger">No hay registros</td>
								<td class="alert alert-danger">No hay registros</td>
								<td class="alert alert-danger">No hay registros</td>
								<td class="alert alert-danger">No hay registros</td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('partials.DataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
	$(document).ready( function () {
		$('#users').DataTable({
			"lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "Todo"] ],

			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
			},
		});
	} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/users/index.blade.php ENDPATH**/ ?>