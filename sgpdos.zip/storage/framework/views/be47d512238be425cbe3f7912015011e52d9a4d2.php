<?php $__env->startSection('links'); ?>
<?php echo $__env->make('partials.DateCKEditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/parsley.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="card">
		<h5 class="card-header">Registrar Aporte</h5>
		<div class="card-body">

			<form action="<?php echo e(route('aportes.store')); ?>" method="POST" data-parsley-validate="">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-12">
						<label for="padrino_id">Buscar Padrinos</label>
						<select class="custom-select <?php echo e($errors->has('padrino_id') ? 'is-invalid' : ''); ?>" name="padrino_id" data-parsley-required data-parsley-validate="parsley">
							<option selected disabled>Seleccionar...</option>
							<?php $__empty_1 = true; $__currentLoopData = $padrinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $padrino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<option value="<?php echo e($padrino->id); ?>" <?php echo e(old('padrino_id')); ?>

								data-apellido="<?php echo e($padrino->apellido); ?>"
								data-alias="<?php echo e($padrino->alias); ?>"
								data-dni="<?php echo e($padrino->dni); ?>"
								data-cuil="<?php echo e($padrino->cuil); ?>"
								data-email="<?php echo e($padrino->email); ?>"
								data-segundo_email="<?php echo e($padrino->segundo_email); ?>"
								data-telefono="<?php echo e($padrino->telefono); ?>"
								data-segundo_telefono="<?php echo e($padrino->segundo_telefono); ?>"
								><?php echo e($padrino->nombre); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<option>No existen registros</option>
								<?php endif; ?>
							</select>
							<?php if ($errors->has('padrino_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('padrino_id'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>

					</div>
					
					<br>
					<b class="mt-3">Infomación del padrino seleccionado</b>
					<div class="row mt-2">
						<div class="col-md-3">
							<div class="from-group">
								<label for="apellido">Apellido</label>
								<input type="text" disabled id="apellido" class="form-control">
							</div>
						</div>
						<div class="col-md-3">
							<label for="alias">Alias</label>
							<input type="text" disabled id="alias" class="form-control">
						</div>
						<div class="col-md-3">
							<label for="dni">DNI</label>
							<input type="text" disabled id="dni" class="form-control">
						</div>
						<div class="col-md-3">
							<label for="cuil">CUIL</label>
							<input type="text" disabled id="cuil" class="form-control">
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3">
							<div class="from-group">
								<label for="email">Email</label>
								<input type="text" disabled id="email" class="form-control">
							</div>
						</div>
						<div class="col-md-3">
							<label for="segundo_email">Segundo Email</label>
							<input type="text" disabled id="segundo_email" class="form-control">
						</div>
						<div class="col-md-3">
							<label for="telefono">Teléfono</label>
							<input type="text" disabled id="telefono" class="form-control">
						</div>
						<div class="col-md-3">
							<label for="segundo_telefono">Segundo teléfono</label>
							<input type="text" disabled id="segundo_telefono" class="form-control">
						</div>
					</div>
					
					<hr class="bg-dark">
					<div class="row mt-3">
						<div class="col-md-4">
							<label for="tipo_pago_id">Medio de pago</label>
							<select class="custom-select <?php echo e($errors->has('tipo_pago_id') ? 'is-invalid' : ''); ?>" name="tipo_pago_id" data-parsley-required>
								<option selected value>Seleccionar...</option>
								<?php $__empty_1 = true; $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->descripcion); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<option>No existen registros</option>
								<?php endif; ?>
							</select>
							<?php if ($errors->has('tipo_pago_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tipo_pago_id'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
						<div class="col-md-4">
							<label for="monto_pago">Monto</label>
							<input type="text" class="form-control <?php echo e($errors->has('monto_pago') ? 'is-invalid' : ''); ?>" name="monto_pago" value="<?php echo e(old('monto_pago')); ?>" data-parsley-required data-parsley-type="number">

							<?php if ($errors->has('monto_pago')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('monto_pago'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
						<div class="col-md-4">
							<label for="fecha_pago">Fecha del pago</label>
							<input type="text" class="form-control <?php echo e($errors->has('fecha_pago') ? 'is-invalid' : ''); ?>" name="fecha_pago" id='datetimepicker1' value="<?php echo e(old('fecha_pago')); ?>" placeholder="DD-MM-YYYY">

							<?php if ($errors->has('fecha_pago')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fecha_pago'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
					</div>
					
					<div class="row mt-3">
						<div class="col-md-4">
							<label for="factura">Factura</label>
							<input type="text" class="form-control <?php echo e($errors->has('factura') ? 'is-invalid' : ''); ?>" name="factura" value="<?php echo e(old('factura')); ?>" data-parsley-required>

							<?php if ($errors->has('factura')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('factura'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
						<div class="col-md-4">
							<label for="comprobante">Comprobante</label>
							<input type="text" class="form-control <?php echo e($errors->has('comprobante') ? 'is-invalid' : ''); ?>" name="comprobante" value="<?php echo e(old('comprobante')); ?>" data-parsley-required>

							<?php if ($errors->has('comprobante')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comprobante'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
						<div class="col-md-4">
							<label for="descripcion">Descripción</label>
							<input type="text" class="form-control <?php echo e($errors->has('descripcion') ? 'is-invalid' : ''); ?>" name="descripcion" value="<?php echo e(old('descripcion')); ?>" data-parsley-required>

							<?php if ($errors->has('descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descripcion'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
					</div>
					

					<button type="submit" class="btn btn-primary mt-3">Guardar</button>

				</form>
			</div>
		</div>

	</div>

	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('scripts'); ?>
	<?php echo $__env->make('partials.parsley', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<script>
		$('select[name="padrino_id"]').on('change',function(e){
			$('#apellido').val($(this).children('option:selected').data('apellido'));
			$('#alias').val($(this).children('option:selected').data('alias'));
			$('#dni').val($(this).children('option:selected').data('dni'));
			$('#cuil').val($(this).children('option:selected').data('cuil'));
			$('#email').val($(this).children('option:selected').data('email'));
			$('#segundo_email').val($(this).children('option:selected').data('segundo_email'));
			$('#telefono').val($(this).children('option:selected').data('telefono'));
			$('#segundo_telefono').val($(this).children('option:selected').data('segundo_telefono'));
		});
	</script>
	<script type="text/javascript">
		$(function () {
			$('#datetimepicker1').datetimepicker({
				locale: 'es',
				viewMode: 'days',
				format: 'DD-MM-YYYY'
			});
		});
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/aportes/create.blade.php ENDPATH**/ ?>