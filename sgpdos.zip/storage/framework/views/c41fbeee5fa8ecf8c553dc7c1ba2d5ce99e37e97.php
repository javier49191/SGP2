<?php $__env->startSection('loader'); ?>
<?php echo $__env->make('partials.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.ChartJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<b>Aportes</b>
					<a href="<?php echo e(route('aportes.create')); ?>" class="btn btn-success float-right">
						Registrar aporte
					</a>
				</div>

				<div class="card-body table-responsive">
					<table id="pagos" class="table table-bordered table-hover" style="width:100%">
						<thead>
							<th>Padrino</th>
							<th>Monto</th>
							<th>Fecha de pago</th>
							<th>Pago ingresado</th>
							<th>Usuario</th>
							
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
	<div class="row mt-3">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header bg-primary text-white">
					<b>Aportes agrupados por año</b>
				</div>
				<div class="card-body">
					<canvas id="aportes"></canvas>
				</div>
			</div>
		</div>
	</div>

	<div class="row justify-content-md-center mt-3">
		
		<div class="col-lg-8">
			<div class="card" style="width: 100%;">
				<div class="card-header bg-primary text-white">
					<b>Tipo Pago</b>
				</div>
				<div class="card-body">
					<canvas id="tipoPagoPie"></canvas>
				</div>
			</div>
		</div>
		
	</div>
	
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('partials.DataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
	$(document).ready( function () {
		$('#pagos').DataTable({
			"lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "Todo"] ],
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
			},
			processing: true,
			serverSide: true,
			deferRender: true,
			oLanguage: {
				"sProcessing": "Procesando..."
			},
			ajax: '<?php echo e(url('aportesDatatable')); ?>',
			columns: [
			{data: 'padrino', name: 'padrino'},
			{data: 'monto_pago', name: 'monto_pago'},
			{data: 'fecha_pago', name: 'fecha_pago'},
			{data: 'created_at', name: 'created_at'},
			{data: 'usuario', name: 'usuario'},
			// {data: 'tipoPago', name: 'tipoPago'},
			]
		});
	} );
</script>


<script>
	let myChart = document.getElementById('aportes').getContext('2d');
	function getRandomColor() {
		var letters = '0123456789ABCDEF'.split('');
		var color = '#';
		for (var i = 0; i < 6; i++ ) {
			color += letters[Math.floor(Math.random() * 16)];
		}
		return color;
	}

	let myBarChart = new Chart(myChart, {
		type: 'bar',
		data: {
			labels: [
			<?php $__empty_1 = true; $__currentLoopData = $agrupados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			"<?php echo e($ag->year); ?>",
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<?php endif; ?>
			],
			datasets: [{
				label: 'Aportes por año $',
				data: [
				<?php $__empty_1 = true; $__currentLoopData = $agrupados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				"<?php echo e($ag->monto); ?>",
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
				],
				backgroundColor: 'rgba(62,149,205,0.5)',
				borderColor: 'rgba(62,149,205,1)',
				borderWidth: 2,
			}]
		},
		options: {
			scales: {
				yAxes: [{
					ticks: {
						beginAtZero:true
					}
				}]
			},
		},

	});

</script>

<script>
	let myChart1 = document.getElementById('tipoPagoPie').getContext('2d');

	let myPieChart1 = new Chart(myChart1, {
		type: 'pie',
		data: {
			labels: [
			'Efectivo',
			'Tarjeta Naranja',
			'Visa',
			'Cheque',
			],
			datasets: [{
				label: 'Activas y no activas',
				data: [
				<?php echo e(tipoPago($pagos, 'Efectivo')); ?>,
				<?php echo e(tipoPago($pagos, 'Tarjeta Naranja')); ?>,
				<?php echo e(tipoPago($pagos, 'Visa')); ?>,
				<?php echo e(tipoPago($pagos, 'Cheque')); ?>,
				],

				backgroundColor: [
				'rgba(92, 184, 92, 1)',
				'rgba(240, 173, 78, 1)',
				'rgba(2, 117, 216, 1)',
				'rgba(217, 83, 79, 1)',				
				],
				borderWidth: 2
			}]
		},

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/aportes/index.blade.php ENDPATH**/ ?>