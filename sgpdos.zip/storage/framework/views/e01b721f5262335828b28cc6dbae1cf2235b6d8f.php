<?php $__env->startSection('links'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-filestyle.js')); ?> "></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<b>Detalles de usuario: <?php echo e($user->name); ?></b>
				</div>

				<div class="card-body">
					<div class="row">
						<div class="col-md-6 form-group">
							<img class="imagen" src="<?php echo e(asset('images/avatar/')); ?>/<?php echo e($user->avatar); ?>" title="avatar de <?php echo e($user->name); ?>">
							<hr>
							<form enctype="multipart/form-data" action="<?php echo e(route('profile')); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<div class="form-group">
									<label for="imagen">Actualizar imagen</label>
									<br>
									<input type="file" id="BSbtndanger" name="avatar" class=" <?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
									
									<input type="submit" class="btn btn-primary mt-2" value="Guardar">
									<?php if($errors->has('avatar')): ?>
									<div role="alert">
										<strong style="color: red;"><?php echo e($errors->first('avatar')); ?></strong>
										<hr>
									</div>

									<?php endif; ?>
								</div>
							</form>
						</div>
						<div class="col-md-6 form-group">
							
							<p class="form-control"><b>Nombre: </b><?php echo e($user->name); ?></p>
							<p class="form-control"><b>Email: </b><?php echo e($user->email); ?></p>
							<p class="form-control"><b>Apellido: </b><?php echo e($user->last_name); ?></p>
							<p class="form-control"><b>Registrado: </b><?php echo e($user->created_at->format('d-m-Y')); ?></p>
							<p class="form-control"><b>Rol: </b><?php echo e($user->role->nombre); ?></p>
							<p class="form-control"><b>Descripción: </b><?php echo e($user->role->descripcion); ?></p>

						</div>
						
					</div>
					
				</div>
			</div>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
	$('#BSbtndanger').filestyle({
		btnClass : 'btn-warning',
		text : 'Nueva',
		htmlIcon: '<i class="icon-file_alt"></i> '
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/users/profile.blade.php ENDPATH**/ ?>