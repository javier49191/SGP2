<?php $__env->startSection('content'); ?>
<div class="container">


	<div class="card">
		<h5 class="card-header">Registrar usuario</h5>
		<div class="card-body">
			<form action="<?php echo e(route('usuarios.store')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-6 form-group">
						<label for="name">Nombre</label>
						<input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>">

						<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="col-md-6 form-group">
						<label for="last_name">Apellido</label>
						<input type="text" class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>" name="last_name" value="<?php echo e(old('last_name')); ?>">
						<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<div class="row">
					<div class="col-md-6 form-group">
						<label for="email">Email</label>
						<input type="text" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>">
						<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>

					<div class="col-md-6 form-group">
						<label for="role_id">Rol</label>

						<select name="role_id" class="custom-select <?php echo e($errors->has('role_id') ? 'is-invalid' : ''); ?>">
							<option selected value>Seleccionar...</option>
							<?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<option value="<?php echo e($role->id); ?>"><?php echo e($role->descripcion); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<?php endif; ?>

						</select>

						<?php if ($errors->has('role_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role_id'); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e(ucfirst($message)); ?></strong>
						</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Guardar</button>
			</form>
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/users/create.blade.php ENDPATH**/ ?>