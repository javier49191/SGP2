<?php $__env->startSection('loader'); ?>
<?php echo $__env->make('partials.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.ChartJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<b>Aportes</b>
					<a href="<?php echo e(route('aportes.create')); ?>" class="btn btn-success float-right">
						Registrar aporte
					</a>
				</div>

				<div class="card-body table-responsive">
					<table id="pagos" class="table table-bordered table-hover" style="width:100%">
						<thead>
							<th>Padrino</th>
							<th>Monto</th>
							<th>Fecha de pago</th>
							<th>Pago ingresado</th>
							<th>Usuario</th>

						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
	
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('partials.DataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
	$(document).ready( function () {
		$('#pagos').DataTable({
			"lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "All"] ],

			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
			},
			processing: true,
            serverSide: true,
            ajax: '<?php echo e(url('aportesDatatable')); ?>',
            columns: [
            {data: 'padrino', name: 'padrino'},
            {data: 'monto_pago', name: 'monto_pago'},
            {data: 'fecha_pago', name: 'fecha_pago'},
            {data: 'created_at', name: 'created_at'},
            {data: 'usuario', name: 'usuario'},
            ]
		});
	} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/aportes/aportes2.blade.php ENDPATH**/ ?>