<?php $__env->startSection('loader'); ?>
<?php echo $__env->make('partials.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('links'); ?>
<?php echo $__env->make('partials.ChartJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
        
        <div class="col-lg-4">
           <div class="card" style="width: 100%;">
            <div class="card-header bg-info text-white">
             <b>Vinculaciones activas y no activas</b>
         </div>
         <div class="card-body">
             <canvas id="vinculaciones">
             </canvas>
             <h6>Total = <?php echo e($vinculados->count() + $Novinculados->count()); ?> vinculaciones</h6>
             <h6>Activas: <?php echo e($vinculados->count()); ?></h6>
             <h6>Inactivas: <?php echo e($Novinculados->count()); ?></h6>
         </div>
     </div>
 </div>
 
 
 <div class="col-lg-4">
    <div class="card" style="width: 100%;">
        <div class="card-header bg-info text-white">
            <b>Alumnos vinculados y no vinculados</b>
        </div>
        <div class="card-body">
            <canvas id="alumnos">
            </canvas>
            <h6>Total = <?php echo e($alumnos->count()); ?> alumnos</h6>
            <h6>Vinculados: <?php echo e($AlumnosVinculados->count()); ?></h6>
            <h6>No vinculados: <?php echo e($alumnos->count()-$AlumnosVinculados->count()); ?></h6>
        </div>
    </div>
</div>


<div class="col-lg-4">
    <div class="card" style="width: 100%;">
        <div class="card-header bg-info text-white">
            <b>Padrinos vinculados y no vinculados</b>
        </div>
        <div class="card-body">
            <canvas id="padrinos">
            </canvas>
            <h6>Total = <?php echo e($padrinos->count()); ?> padrinos</h6>
            <h6>Vinculados: <?php echo e($PadrinosVinculados->count()); ?></h6>
            <h6>No vinculados: <?php echo e($padrinos->count()-$PadrinosVinculados->count()); ?></h6>
        </div>
    </div>
</div>


</div>

<div class="row mt-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <b>
                Vinculaciones activas
                </b>
                <a href="<?php echo e(route('vinculaciones.create')); ?>" class="btn btn-success float-right border">Crear vinculación</a>
            </div>
            <div class="card-body table-responsive">
                    <table id="activas" class="table table-bordered table-hover" style="width:100%">
                        <thead>
                            <th>Alumno</th>
                            <th>Padrino</th>
                            <th class="text-center">Fecha de vinculación</th>
                            <th class="text-center">Observaciones</th>
                        </thead>
                    </table>
                </div>
        </div>
    </div>
</div>



<div class="row mt-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <b>Vinculaciones Inactivas</b>
            </div>
            <div class="card-body table-responsive">
                    <table id="inactivas" class="table table-bordered table-hover" style="width:100%">
                        <thead>
                            <th>Alumno</th>
                            <th>Padrino</th>
                            <th class="text-center">Fecha de vinculación</th>
                            <th class="text-center">Fecha de eliminación</th>
                            <th class="text-center">Observaciones</th>
                        </thead>
                    </table>
                </div>
        </div>
    </div>
</div>


</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
	let myChart = document.getElementById('vinculaciones').getContext('2d');

	let myDoughnutChart = new Chart(myChart, {
        type: 'doughnut',
        data: {
            labels: [
            'Activas',
            'Inactivas',
            ],
            datasets: [{
                label: 'Activas y Inactivas',
                data: [
                <?php echo e($vinculados->count()); ?>,
                <?php echo e($Novinculados->count()); ?>],
                backgroundColor: [
                'rgba(92, 184, 92, 0.8)',
                'rgba(217, 83, 79, 0.8)',
                ],
                borderColor: [],
                borderWidth: 2
            }]
        },

    });
</script>

<script>
    let myChart2 = document.getElementById('alumnos').getContext('2d');

    let myPieChart2 = new Chart(myChart2, {
        type: 'pie',
        data: {
            labels: [
            'Vinculados',
            'No vinculados',
            ],
            datasets: [{
                label: 'Activas y no activas',
                data: [
                <?php echo e($AlumnosVinculados->count()); ?>,
                <?php echo e($alumnos->count() - $AlumnosVinculados->count()); ?>],
                backgroundColor: [
                'rgba(92, 184, 92, 1)',
                'rgba(255, 99, 132, 1)',
                ],
                borderColor: [],
                borderWidth: 2
            }]
        },

    });
</script>

<script>
    let myChart3 = document.getElementById('padrinos').getContext('2d');

    let myPieChart3 = new Chart(myChart3, {
        type: 'pie',
        data: {
            labels: [
            'Vinculados',
            'No vinculados',
            ],
            datasets: [{
                label: 'Activas y no activas',
                data: [
                <?php echo e($PadrinosVinculados->count()); ?>,
                <?php echo e($padrinos->count() - $PadrinosVinculados->count()); ?>],
                backgroundColor: [
                'rgba(92, 184, 92, 1)',
                'rgba(255, 99, 132, 1)',
                ],
                borderColor: [
                // 'rgba(41, 43, 44, 0.8)',
                // 'rgba(41, 43, 44, 0.8)',
                ],
                borderWidth: 2
            }]
        },

    });
</script>




<?php echo $__env->make('partials.DataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <script>
    $(document).ready( function () {
        $('#activas').DataTable({
            "lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "Todo"] ],
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
            },
            processing: true,
            serverSide: true,
            ajax: '<?php echo e(url('vinculacionesDatatable')); ?>',
            columns: [
            {data: 'alumno', name: 'alumno'},
            {data: 'padrino', name: 'padrino'},
            {data: 'fecha_vinculacion', name: 'fecha_vinculacion'},
            {data: 'observaciones', name: 'observaciones'},
            ]
        });
    } );
</script>


<?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    $(document).ready( function () {
        $('#inactivas').DataTable({
            "lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "Todo"] ],
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
            },
            processing: true,
            serverSide: true,
            ajax: '<?php echo e(url('novinculadoDatatable')); ?>',
            columns: [
            {data: 'alumno', name: 'alumno'},
            {data: 'padrino', name: 'padrino'},
            {data: 'fecha_vinculacion', name: 'fecha_vinculacion'},
            {data: 'fecha_eliminacion', name: 'fecha_eliminacion'},
            {data: 'observaciones', name: 'observaciones'},
            ]
        });
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgp2\resources\views/vinculaciones/index.blade.php ENDPATH**/ ?>